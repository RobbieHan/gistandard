-- MySQL dump 10.13  Distrib 5.7.15, for linux-glibc2.5 (x86_64)
--
-- Host: localhost    Database: gistandard
-- ------------------------------------------------------
-- Server version	5.7.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `rbac_menu`
--

DROP TABLE IF EXISTS `rbac_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rbac_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(32) NOT NULL,
  `is_top` tinyint(1) NOT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `url` varchar(128) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `url` (`url`),
  KEY `rbac_menu_parent_id_60a5b178_fk_rbac_menu_id` (`parent_id`),
  CONSTRAINT `rbac_menu_parent_id_60a5b178_fk_rbac_menu_id` FOREIGN KEY (`parent_id`) REFERENCES `rbac_menu` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rbac_menu`
--

LOCK TABLES `rbac_menu` WRITE;
/*!40000 ALTER TABLE `rbac_menu` DISABLE KEYS */;
INSERT INTO `rbac_menu` VALUES (1,'系统',0,NULL,'SYSTEM','/system/',NULL),(2,'行政',0,NULL,'ADM','/adm/',NULL),(3,'人事',0,NULL,'PERSONNEL','/personnel/',NULL),(4,'流程',0,NULL,'FLOW','/flow/',NULL),(5,'我的工作台',0,NULL,'PERSONAL','/personal/',NULL),(6,'基础设置',0,'fa fa-gg','SYSTEM-BASIC',NULL,1),(7,'权限管理',0,'fa fa-user-plus','SYSTEM-RBAC',NULL,1),(8,'系统工具',0,'fa fa-wrench','SYSTEM-TOOLS',NULL,1),(9,'组织架构',0,NULL,'SYSTEM-BASIC-STRUCTURE','/system/basic/structure/',6),(10,'用户管理',0,NULL,'SYSTEM-BASIC-USER','/system/basic/user/',6),(11,'菜单管理',0,NULL,'SYSTEM-RBAC-MENU','/system/rbac/menu/',7),(12,'角色管理',0,NULL,'SYSTEM-RBAC-ROLE','/system/rbac/role/',7),(15,'组织架构：列表',0,NULL,'SYSTEM-BASIC-STRUCTURE-LIST','/system/basic/structure/list',9),(16,'组织架构：详情',0,NULL,'SYSTEM-BASIC-STRUCTURE-DETAIL','/system/basic/structure/detail',9),(17,'组织架构：删除',0,NULL,'SYSTEM-BASIC-STRUCTURE-DELETE','/system/basic/structure/delete',9),(18,'组织架构：关联用户',0,NULL,'SYSTEM-BASIC-STRUCTURE-ADD_USER','/system/basic/structure/add_user',9),(19,'用户管理：列表',0,NULL,'SYSTEM-BASIC-USER-LIST','/system/basic/user/list',10),(20,'用户管理：详情',0,NULL,'SYSTEM-BASIC-USER','/system/basic/user/detail',10),(21,'用户管理：修改',0,NULL,'SYSTEM-BASIC-USER-UPDATE','/system/basic/user/update',10),(22,'用户管理：创建',0,NULL,'SYSTEM-BASIC-USER-CREATE','/system/basic/user/create',10),(23,'用户管理：删除',0,NULL,'SYSTEM-BASIC-USER-DELETE','/system/basic/user/delete',10),(24,'用户管理：启用',0,NULL,'SYSTEM-BASIC-USER-ENABLE','/system/basic/user/enable',10),(25,'用户管理：禁用',0,NULL,'SYSTEM-BASIC-USER-DISABLE','/system/basic/user/disable',10),(26,'用户管理：修改用户密码',0,NULL,'SYSTEM-BASIC-USER-AdminPasswdChange','/system/basic/user/adminpasswdchange',10),(27,'角色管理：列表',0,NULL,'SYSTEM-RBAC-ROLE-LIST','/system/rbac/role/list',12),(28,'角色管理：详情-编辑',0,NULL,'SYSTEM-RBAC-ROLE-DETAIL','/system/rbac/role/detail',12),(29,'角色管理：删除',0,NULL,'SYSTEM-RBAC-ROLE-DELETE','/system/rbac/role/delete',12),(30,'角色管理：关联菜单',0,NULL,'SYSTEM-RBAC-ROLE-ROLE_MENU','/system/rbac/role/role_menu',12),(31,'角色管理：菜单列表',0,NULL,'SYSTEM-RBAC-ROLE-ROLE_MENU_LIST','/system/rbac/role/role_menu_list',12),(32,'角色管理：关联用户',0,NULL,'SYSTEM-RBAC-ROLE-ROLE_LIST','/system/rbac/role/role_user',12),(33,'菜单管理：列表',0,NULL,'SYSTEM-RBAC-MENU-LIST','/system/rbac/menu/list',11),(34,'系统设置',0,NULL,'SYSTEM-TOOLS-SYSTEM_SETUP','/system/tools/system_setup/',8),(35,'发件邮箱设置',0,NULL,'SYSTEM-TOOLS-EMAIL_SETUP','/system/tools/email_setup/',8),(36,'基础管理',0,'fa fa-gg','ADM-BSM',NULL,2),(37,'分销商管理',0,NULL,'ADM-BSM-SUPPLIER','/adm/bsm/supplier/',36),(38,'供应商管理：列表',0,NULL,'ADM-BSM-SUPPLIER-LIST','/adm/bsm/supplier/list',37),(39,'基础管理：详情-修改',0,NULL,'ADM-BSM-SUPPLIER-DETAIL','/adm/bsm/supplier/detail',37),(40,'供应商管理：删除',0,NULL,'ADM-BSM-SUPPLIER-DELETE','/adm/bsm/supplier/delete',37),(41,'资产类型',0,NULL,'ADM-BSM-ASSETTYPE','/adm/bsm/assettype/',36),(42,'资产类型：列表',0,NULL,'ADM-BSM-ASSETTYPE-LIST','/adm/bsm/assettype/list',41),(43,'资产类型：编辑-详情',0,NULL,'ADM-BSM-ASSETYPE-DETAIL','/adm/bsm/assettype/detail',41),(44,'资产类型：删除',0,NULL,'ADM-BSM-ASSETTYPE-DELETE','/adm/bsm/assettype/delete',41),(45,'客户信息',0,NULL,'ADM-BSM-CUSTOMER','/adm/bsm/customer/',36),(46,'客户信息：列表',0,NULL,'ADM-BSM-CUSTOMER-LIST','/adm/bsm/customer/list',45),(47,'客户信息：编辑-详情',0,NULL,'ADM-BSM-CUSTOMER-DETAIL','/adm/bsm/customer/detail',45),(48,'客户信息：删除',0,NULL,'ADM-BSM-CUSTOMER-DELETE','/adm/bsm/customer/delete',45),(49,'设备类型',0,NULL,'ADM-BSM-EQUIPMENTTYPE','/adm/bsm/equipmenttype/',36),(50,'资产管理',0,'fa fa-desktop','ADM-DEV','/adm/asset/',2),(51,'设备管理',0,'fa fa-keyboard-o','ADM-EQUIPMENT','/adm/equipment/',2),(52,'用户管理：修改个人密码',0,NULL,'SYSTEM-BASIC-USER-PASSWDCHANGE','/system/basic/user/passwdchange',10),(53,'设备类型：列表',0,NULL,'ADM-BSM-EQUIPMENTTYPE-LIST','/adm/bsm/equipmenttype/list',49),(54,'设备类型：编辑-详情',0,NULL,'ADM-BSM-EQUIPMENTTYPE-DETAIL','/adm/bsm/equipmenttype/detail',49),(55,'设备类型：删除',0,NULL,'ADM-BSM-EQUIPMENTTYPE-DELETE','/adm/bsm/equipmenttype/delete',49),(56,'设备管理：列表',0,NULL,'ADM-EQUIPMENT-LIST','/adm/equipment/list',51),(57,'设备管理：新建-修改',0,NULL,'ADM-EQUIPMENT-CREATE','/adm/equipment/create',51),(58,'设备管理：删除',0,NULL,'ADM-EQUIPMENT-DELETE','/adm/equipment/delete',51),(59,'设备管理：详情',0,NULL,'ADM-EQUIPMENT-DETAIL','/adm/equipment/detail',51),(60,'设备管理：维保更新',0,NULL,'ADM-EQUIPMENT-SERVICEINFO','/adm/equipment/serviceinfoupdate',51),(61,'个人中心',0,'fa fa-user-plus','PERSONAL-USERINFO','/personal/userinfo',5),(62,'上传头像',0,NULL,'PERSONAL-USERINFO-UPLOADIMAGE','/personal/uploadimage',61),(63,'修改密码',0,NULL,'PERSONAL-USERINFO-PASSWORDCHANGE','/personal/passwordchange',61),(64,'内部通信',0,'fa fa-book','PERSONAL-PHONEBOOK','/personal/phonebook',5),(65,'菜单管理：详情-修改',0,NULL,'SYSTEM-RBAC-MENU-DETAIL','/system/rbac/menu/detail',11),(66,'工单管理',1,'fa fa-list-alt','PERSONAL-WORKORDER',NULL,5),(67,'我创建的工单',1,'fa fa-caret-right','PERSONAL-WORKORDER_ICRT','/personal/workorder_Icrt/',66),(68,'我创建的工单：创建',1,NULL,'PERSONAL-WORKORDER_ICRT-CREATE','/personal/workorder_Icrt/create',67),(69,'我创建的工单：列表',1,NULL,'PERSONAL-WORKORDER_ICRT-LIST','/personal/workorder_Icrt/list',67),(70,'我创建的工单：详情',1,NULL,'PERSONAL-WORKORDER-DETAIL','/personal/workorder_Icrt/detail',67),(71,'我创建的工单：删除',1,NULL,'PERSONAL-WORKORDER_ICRT-DELETE','/personal/workorder_Icrt/delete',67),(72,'我创建的工单：修改',1,NULL,'PERSONAL-WORKORDER-UPDATE','/personal/workorder_Icrt/update',67),(73,'我审批的工单',1,'fa fa-caret-right','PERSONAL-WORKORDER_APP','/personal/workorder_app/',66),(74,'我收到的工单',1,'fa fa-caret-right','PERSONAL-WORKORDER_REC','/personal/workorder_rec/',66),(75,'我审批的工单：派发',1,NULL,'PERSONAL-WORKORDER_APP-SEND','/personal/workorder_app/send',73),(76,'我收到的工单：执行',1,NULL,'PERSONAL-WORKORDER-EXECUTE','/personal/workorder_rec/execute',74),(77,'我收到的工单：确认',1,NULL,'PERSONAL-WORKORDER_REC-FINISH','/personal/workorder_rec/finish',74),(78,'我收到的工单：文件上传',1,NULL,'PERSONAL-WORKORDER_REC-UPLOAD','/personal/workorder_rec/upload',74),(79,'我创建的工单：文件上传',1,NULL,'PERSONAL-WORKORDER_ICRT-UPLOAD','/personal/workorder_Icrt/upload',67);
/*!40000 ALTER TABLE `rbac_menu` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-05-30  7:00:02
